var hierarchy =
[
    [ "Maze", "class_maze.html", null ],
    [ "MonoBehaviour", null, [
      [ "MazeObject", "class_maze_object.html", null ]
    ] ],
    [ "Maze.Point", "class_maze_1_1_point.html", null ]
];