var files_dup =
[
    [ "MazeClass.cs", "_maze_class_8cs.html", [
      [ "Maze", "class_maze.html", "class_maze" ],
      [ "Maze.Point", "class_maze_1_1_point.html", "class_maze_1_1_point" ]
    ] ],
    [ "MazeObject.cs", "_maze_object_8cs.html", [
      [ "MazeObject", "class_maze_object.html", "class_maze_object" ]
    ] ]
];